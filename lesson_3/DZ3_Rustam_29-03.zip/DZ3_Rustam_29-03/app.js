//DZ3 NO/1
var arrNums = [123,234,256,345,456,567,543,67,23,28,50]
var newArray = []
for (var i = 0; i < arrNums; i++){
 if (arrNums[i].toString()[0] === '2' || arrNums[i].toString()[0] === '5'){
  newArray.push(arrNums[i])
   }
 }
console.log(newArray)


//DZ3 NO/2
// var dataType = function (text) {
//  return prompt(typeof text )
// }
// dataType(prompt())